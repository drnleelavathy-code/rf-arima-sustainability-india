# dataset_generation_script.py
# Seed=42 | n=10,512 | Python 3.9+
# Run this file to regenerate synthetic_consumer_dataset.csv

import numpy as np
import pandas as pd

SEED = 42
np.random.seed(SEED)
N = 10_512

# See full annotated script in MDPI_Supplementary_Dataset.zip
# or run the full Colab notebook provided with the paper.
